# Text as Data for Economists — open-source text classifiers

Course material for economics students at Universidad del Pacífico.

## Contents

| File | What it is |
|---|---|
| `text_classification_for_economists.ipynb` | The notebook. Five modules, each with explanations, questions to answer before running, code and exercises. |
| `data/` | All datasets as CSV files (about 9 MB). See `data/SOURCES.md` for origin and licences. |
| `scripts/build_data.py` | Rebuilds `data/` from the original public sources. Not needed unless a file is lost. |
| `requirements.txt` | Libraries with minimum versions. |
| `requirements-tested.txt` | The exact versions the code was executed with. |

## Important: the notebook has not been run with the real models

The notebook is delivered **without outputs**. Its code was executed end to end, on both the fast and the full settings, using tiny randomly initialised stand-in models in place of the real ones, because the environment where it was written could not reach the Hugging Face Hub. That confirms the data loading, training loops, evaluation, plots and regressions all run with the library versions in `requirements-tested.txt`. It does **not** confirm the downloads of the seven real models, their memory use, or their running time. Run the notebook once yourself before class.

**Update, 6 October 2026.** The notebook has now been run from the first cell to the last with the seven real models, unmodified, in `FAST_MODE` on a Windows 11 laptop without a GPU (Intel i5-13420H, 16 GB RAM, Python 3.13). It took 27 minutes with the models already downloaded. `RUN_REPORT.md` has the numbers and the problems met on the way. The full setting (`FAST_MODE = False`, GPU) has still not been run with the real models.

## Running it

**Google Colab (recommended for class).** Upload and unzip this folder, open the notebook, choose *Runtime → Change runtime type → T4 GPU*, uncomment the `%pip install` line in the first code cell and run all cells.

**Your own computer.**

```
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
jupyter lab
```

Start Jupyter from this folder so that `data/` is found.

The first run downloads seven models from the Hugging Face Hub, roughly 3.5 GB in total, and needs an internet connection. Later runs use the local cache. (Measured on 6 October 2026: the cache took 4.4 GB on disk, because `transformers` keeps both the original `.bin` file and a converted `safetensors` copy for BETO and mmBERT-small.)

## Speed

`FAST_MODE` turns on by itself when no GPU is found. It trains on smaller samples and scores every fourth FOMC meeting, so results are lower and noisier than in the full run. Set `FAST_MODE = False` in the configuration cell to force the full run. Running times have not been measured with the real models on a GPU; expect minutes. On a laptop CPU (8 cores, no GPU) the `FAST_MODE` run took 27 minutes: about 10 for Module 1, 5 for Module 3, 1 for Module 4, 6 for Module 5 and 5 for Module 6.

## Models

| Key in `MODELS` | Hugging Face id | Used for |
|---|---|---|
| `modernbert` | `answerdotai/ModernBERT-base` | Module 1 fine-tuning; Module 6 |
| `multilingual` | `jhu-clsp/mmBERT-small` | Module 1 cross-lingual transfer |
| `embedder` | `intfloat/multilingual-e5-small` | Modules 3 and 4 (embeddings, SetFit) |
| `beto` | `dccuchile/bert-base-spanish-wwm-cased` | Module 5 fine-tuning |
| `robertuito` | `pysentimiento/robertuito-base-uncased` | Module 5 fine-tuning |
| `sent_tweets` | `pysentimiento/robertuito-sentiment-analysis` | Module 5 off-the-shelf |
| `sent_reviews` | `nlptown/bert-base-multilingual-uncased-sentiment` | Module 5 off-the-shelf |

All seven identifiers were checked to exist on the Hub in October 2026.

## If something fails

* **`KeyError: 'modernbert'` or "model type modernbert not recognised".** `transformers` is too old. Upgrade to 4.48 or newer.
* **An error while loading BETO that mentions `torch.load` or `weights_only`.** BETO is distributed in the older `.bin` format, which recent `transformers` only loads with `torch` 2.6 or newer. Upgrade `torch`.
* **Out of memory on the GPU.** Lower `batch_size` in the `finetune` calls, or restart the kernel and run one module at a time. Each module only needs the setup cells; Module 6 also needs Modules 1 and 3.
* **An error on Apple Silicon mentioning MPS.** Set `DEVICE = "cpu"` in the configuration cell.
* **SetFit import or training error after a library upgrade.** Install the versions in `requirements-tested.txt`.
* **Every prediction is the same class.** Training was too short or the learning rate was wrong for that model. Check that the printed loss falls from one epoch to the next.
* **On Windows: `OSError: [WinError 4551]` or `ImportError: DLL load failed`, with a message that an Application Control policy blocked the file** (in Spanish: *"Una directiva de Control de aplicaciones bloqueó este archivo"*) when importing `torch`, `sklearn` or `statsmodels`. This is Windows 11 *Smart App Control* refusing to load library files it does not recognise yet. It is not an error in the notebook, and reinstalling the same versions does not help. The simplest way round it is Google Colab. On your own machine, use Python 3.13 rather than the newest Python, and if one library is still blocked, install the release just before it (for example `pip install scikit-learn==1.9.0 statsmodels==0.14.6`). Some files are blocked only the first time and load a few minutes later. Turning Smart App Control off also works, but that is a security decision for the owner of the computer.
* **A cell that loads a model seems frozen: the progress bar does not move and the processor is idle.** The download has hung. Interrupt or restart the kernel and run the cells again; files that were already downloaded are not fetched twice. If it keeps happening, set the environment variable `HF_HUB_DISABLE_XET=1` before starting Jupyter, which makes the Hugging Face library use plain HTTP downloads.

## Teaching notes

* The Spanish sentences, messages and job titles inside the notebook (Modules 1, 3 and 4) were written for the class as illustrations. They are labelled as such and are not quotations or data.
* The tweets in Module 5 are real and some contain coarse language.
* Each module ends with exercises. The closing section sets a course project: a monetary policy tone index for Peru from BCRP statements.
