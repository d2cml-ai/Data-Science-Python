# Data sources

Every file in this folder is real, public data. Nothing was generated or simulated.
`scripts/build_data.py` downloads each original file and produces these CSVs; read it to see the exact steps.

| Folder | Used in | What it is | Original source | Licence |
|---|---|---|---|---|
| `fomc/` | Modules 1 and 6 | US Federal Reserve (FOMC) sentences labelled dovish / hawkish / neutral; all meeting-minutes sentences 1996–2022 with the authors' model labels; US CPI and Treasury yields | Shah, Paturi and Chava (2023), "Trillion Dollar Words", ACL. https://github.com/gtfintechlab/fomc-hawkish-dovish | CC BY-NC 4.0 (non-commercial use, with attribution) |
| `banking77/` | Modules 3 and 6 | 13,083 customer-service messages to an online bank, 77 categories | Casanueva et al. (2020). https://github.com/PolyAI-LDN/task-specific-datasets | CC BY 4.0 |
| `esco/` | Module 4 | ESCO v1.1.1 occupations with alternative titles and their ISCO-08 unit group; ISCO-08 group names and descriptions | European Commission (ESCO), CSV export by the Tabiya project. https://github.com/tabiya-tech/tabiya-open-dataset and https://esco.ec.europa.eu | ESCO is published by the European Commission for reuse with attribution. Check the ESCO site for the current terms. |
| `tweets_es/` | Module 5 | Spanish tweets labelled negative / neutral / positive | Barbieri et al. (2022), XLM-T. https://github.com/cardiffnlp/xlm-t | The repository refers users to the licences of the underlying datasets and to Twitter's terms. Use for teaching and research; do not republish. |

## Notes

* **FOMC files.** `train.csv` and `test.csv` are the authors' combined split with seed 5768. Labels: 0 = dovish, 1 = hawkish, 2 = neutral. A few dozen sentences were stored with broken character encoding in the original files and were repaired. `minutes_sentences.csv` holds the labels produced by the authors' model (`authors_label`), not human labels. `meetings.csv` holds the authors' published tone measure for each meeting. `cpi.csv` (CPIAUCSL) and `treasury_yields.csv` end in late 2022.
* **Tweets.** These are real tweets and some contain coarse language. User names were replaced with `@user` by the dataset's authors.
* **None of these datasets is Peruvian.** No public, hand-labelled Peruvian dataset was found for these tasks. The notebook says so in each module and sets exercises that build Peruvian test sets.
